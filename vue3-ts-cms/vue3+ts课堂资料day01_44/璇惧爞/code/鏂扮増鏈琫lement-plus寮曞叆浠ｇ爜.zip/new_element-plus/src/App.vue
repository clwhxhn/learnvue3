<template>
  <el-button>Coderwhy Default</el-button>
  <el-button type="primary">Coderwhy Primary</el-button>
  <el-button type="success">Coderwhy Success</el-button>
  <el-button type="info">Coderwhy Info</el-button>
  <el-button type="warning">Coderwhy Warning</el-button>
  <el-button type="danger">Coderwhy Danger</el-button>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({
  name: "App",
  components: {},
});
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
